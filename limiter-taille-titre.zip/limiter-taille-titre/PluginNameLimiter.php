<?php
/*
Plugin Name: Limiter Taille Titres
Plugin URI: https://exemple.com/limiter-taille-titres
Description: Limite la taille des titres à 80 caractères
Version: 1.0
Author: Votre nom
Author URI: https://exemple.com
License: GPLv2 or later
Text Domain: limiter-taille-titres
*/

function ltt_limiter_taille_titres($title) {
    return substr($title, 0, 80);
}
add_filter('the_title', 'ltt_limiter_taille_titres');
